/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HeroSection } from './components/HeroSection';
import { ScrollCanvas } from './components/ScrollCanvas';
import { PerformanceSection } from './components/PerformanceSection';
import { StorySection } from './components/StorySection';
import { TechSection } from './components/TechSection';
import { ModelsSection } from './components/ModelsSection';
import { ConfiguratorSection } from './components/ConfiguratorSection';
import { CtaSection } from './components/CtaSection';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="relative bg-[#090A0C]">
      {/* One fixed background; frames advance with the scroll of the whole page */}
      <ScrollCanvas />

      {/* Tall track: the sticky stage keeps the hero pinned while the first frames play */}
      <div className="relative z-10 h-[300vh]">
        <div className="sticky top-0 h-dvh w-full overflow-hidden">
          <div
            className="absolute inset-0 pointer-events-none bg-gradient-to-r from-black/55 via-black/10 to-transparent"
            aria-hidden="true"
          />
          <div className="relative h-full">
            <HeroSection />
          </div>
        </div>
      </div>

      <div>
        <PerformanceSection />
        <StorySection />
        <TechSection />
        <ModelsSection />
        <ConfiguratorSection />
        <CtaSection />
      </div>
      <Footer />
    </div>
  );
}
