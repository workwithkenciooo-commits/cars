import { Battery, Cpu, Wind, Zap } from 'lucide-react';
import { Kicker, Reveal, Shell, H2, LEAD, useInView } from './ui';

const FEATURES = [
  { icon: Battery, title: 'Solid-state pack', stat: '900V', text: 'A structural, liquid-cooled pack that holds output without thermal fade.' },
  { icon: Cpu, title: 'Silicon-carbide inverters', stat: 'SiC', text: 'Faster switching and lower losses for sharper response and longer range.' },
  { icon: Wind, title: 'Active underbody aero', stat: '0.19 Cd', text: 'Adaptive panels keep the car slippery at speed and planted in corners.' },
  { icon: Zap, title: 'Ultra-fast charging', stat: '420 kW', text: 'Peak charge rate that turns a stop into a short pause.' },
];

export function TechSection() {
  const [ref, seen] = useInView<HTMLDivElement>(0.4);
  return (
    <Shell id="tech" labelledBy="tech-heading">
      <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-end mb-16 sm:mb-20">
        <div className="lg:col-span-7">
          <Reveal><Kicker>Architecture</Kicker></Reveal>
          <Reveal delay={100}><h2 id="tech-heading" className={H2}>Power,<br />re-engineered.</h2></Reveal>
        </div>
        <Reveal delay={200} className="lg:col-span-5">
          <p className={`${LEAD} max-w-[44ch]`}>
            Aerodynamics, power electronics and thermal management are designed as one system,
            so the car delivers the same performance on the tenth lap as the first.
          </p>
        </Reveal>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {FEATURES.map((f, i) => (
          <Reveal key={f.title} delay={i * 100}>
            <article className="h-full rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md p-6 sm:p-7 hover:border-white/30 hover:bg-black/30 transition-colors duration-300">
              <f.icon className="w-6 h-6 text-[#ff3a4d] mb-10" strokeWidth={1.5} aria-hidden="true" />
              <p className="font-display text-3xl font-semibold tracking-tight mb-2">{f.stat}</p>
              <h3 className="font-display text-xs tracking-[0.16em] uppercase text-zinc-300 mb-3">{f.title}</h3>
              <p className="text-sm leading-relaxed text-zinc-400">{f.text}</p>
            </article>
          </Reveal>
        ))}
      </div>

      {/* Charging meter */}
      <Reveal delay={100} className="mt-4">
        <div ref={ref} className="rounded-2xl border border-white/10 bg-black/40 backdrop-blur-md p-6 sm:p-8">
          <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
            <div>
              <p className="font-display text-xs tracking-[0.2em] uppercase text-zinc-400 mb-2">10–80% charge</p>
              <p className="font-display text-4xl sm:text-5xl font-semibold tracking-tight">11 minutes</p>
            </div>
            <p className="text-sm text-zinc-400 max-w-[34ch]">At a peak charge rate of 420 kW on a compatible fast charger.</p>
          </div>
          <div className="relative h-2 rounded-full bg-white/10 overflow-hidden" role="img" aria-label="Charging from 10 to 80 percent">
            <div
              className="absolute inset-y-0 left-[10%] rounded-full bg-gradient-to-r from-[#e5001c] to-[#ff6a78] transition-[width] duration-[1800ms] ease-out"
              style={{ width: seen ? '70%' : '0%' }}
            />
          </div>
          <div className="flex justify-between mt-3 text-[11px] tracking-[0.14em] uppercase text-zinc-500 tabular-nums">
            <span>0%</span><span>10%</span><span>80%</span><span>100%</span>
          </div>
        </div>
      </Reveal>
    </Shell>
  );
}
