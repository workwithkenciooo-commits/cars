import { useEffect, useRef, useState, type ReactNode } from 'react';

export const openReserve = () => window.dispatchEvent(new Event('aero:reserve'));

export function useInView<T extends Element>(threshold = 0.2) {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setSeen(true); io.disconnect(); } },
      { threshold },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return [ref, seen] as const;
}

/** Fade + rise on first view */
export function Reveal({ children, delay = 0, className = '' }: { children: ReactNode; delay?: number; className?: string }) {
  const [ref, seen] = useInView<HTMLDivElement>(0.15);
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={`transition-all duration-[900ms] ease-out ${seen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'} ${className}`}
    >
      {children}
    </div>
  );
}

export function Kicker({ children }: { children: ReactNode }) {
  return (
    <p className="font-display text-xs sm:text-sm font-medium tracking-[0.22em] uppercase text-zinc-400 mb-4 flex items-center gap-3">
      <span className="inline-block w-8 h-px bg-[#e5001c]" aria-hidden="true" />
      {children}
    </p>
  );
}

export const H2 = 'font-display font-semibold uppercase tracking-[-0.025em] leading-[0.96] text-[clamp(2.5rem,7vw,5.5rem)] text-balance';
export const LEAD = 'font-sans text-[clamp(1rem,1.5vw,1.1875rem)] leading-[1.6] text-zinc-300/90';
export const BTN_PRIMARY =
  'inline-flex items-center justify-center min-h-[48px] px-8 py-3 rounded-full bg-white text-[#090A0C] hover:bg-zinc-200 active:scale-[0.99] font-display text-[13px] font-semibold tracking-[0.1em] uppercase transition-all duration-200 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white';
export const BTN_GHOST =
  'inline-flex items-center justify-center min-h-[48px] px-8 py-3 rounded-full border border-white/30 text-white hover:border-white/75 hover:bg-white/[0.06] active:scale-[0.99] font-display text-[13px] font-medium tracking-[0.1em] uppercase transition-all duration-200 whitespace-nowrap cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white';

/** Section wrapper: transparent so the fixed animation shows through, with a legibility scrim */
export function Shell({ id, labelledBy, children, scrim = 'bg-black/55' }: { id?: string; labelledBy: string; children: ReactNode; scrim?: string }) {
  return (
    <section id={id} aria-labelledby={labelledBy} className="relative z-10 w-full text-white overflow-hidden">
      <div className={`absolute inset-0 ${scrim} pointer-events-none`} aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/45 to-transparent pointer-events-none" aria-hidden="true" />
      <div className="relative max-w-[1440px] mx-auto px-5 sm:px-8 md:px-12 lg:px-16 py-24 sm:py-32 lg:py-40">{children}</div>
    </section>
  );
}
