import { AeroLogo } from './AeroLogo';
import { openReserve } from './ui';

const LINKS = [['Models', '#models'], ['Tech', '#tech'], ['Story', '#story'], ['Configurator', '#configurator']];

export function Footer() {
  const go = (e: React.MouseEvent, href: string) => {
    e.preventDefault();
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };
  return (
    <footer className="relative z-10 text-white bg-black/80 backdrop-blur-md border-t border-white/10">
      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 md:px-12 lg:px-16 py-14 sm:py-16 grid gap-10 md:grid-cols-12">
        <div className="md:col-span-6">
          <AeroLogo className="h-[17px] w-auto mb-5" />
          <p className="text-sm text-zinc-400 max-w-[38ch] leading-relaxed">The ultimate electric grand tourer, built for the next era.</p>
        </div>
        <nav aria-label="Footer" className="md:col-span-4 grid grid-cols-2 gap-3 content-start">
          {LINKS.map(([l, h]) => (
            <a key={l} href={h} onClick={(e) => go(e, h)} className="font-display text-xs tracking-[0.14em] uppercase text-zinc-400 hover:text-white transition-colors py-1">{l}</a>
          ))}
        </nav>
        <div className="md:col-span-2 md:text-right">
          <button type="button" onClick={openReserve} className="font-display text-xs tracking-[0.14em] uppercase px-6 min-h-[40px] rounded-full border border-white/30 hover:bg-white hover:text-[#090A0C] transition-colors cursor-pointer">Reserve</button>
        </div>
      </div>
      <div className="max-w-[1440px] mx-auto px-5 sm:px-8 md:px-12 lg:px-16 py-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-zinc-500">
        <p>© 2026 AERO. All rights reserved.</p>
        <button type="button" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:text-white transition-colors cursor-pointer tracking-[0.14em] uppercase">Back to top ↑</button>
      </div>
    </footer>
  );
}
