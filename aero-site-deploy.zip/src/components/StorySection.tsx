import { Kicker, Reveal, Shell, H2, LEAD } from './ui';

const PRINCIPLES = [
  { n: '01', title: 'Front splitter', text: 'Sets the stagnation point low, sending clean, fast air under and around the body.' },
  { n: '02', title: 'Boundary-layer control', text: 'Every surface guides flow from nose to tail with no breaks to trip it into turbulence.' },
  { n: '03', title: 'Active rear diffuser', text: 'Deploys with speed to trade drag for downforce exactly when the road asks for it.' },
];

const FACTS = [
  { label: 'Curb weight', value: '4,180 lb' },
  { label: 'Chassis', value: 'Carbon monocoque' },
  { label: 'Production', value: 'Limited series' },
];

export function StorySection() {
  return (
    <Shell id="story" labelledBy="story-heading">
      <div className="grid lg:grid-cols-12 gap-12 lg:gap-16">
        <div className="lg:col-span-6">
          <Reveal><Kicker>Philosophy</Kicker></Reveal>
          <Reveal delay={100}>
            <h2 id="story-heading" className={H2}>Sculpted<br />by airflow.</h2>
          </Reveal>
          <Reveal delay={200}>
            <p className={`${LEAD} mt-8 max-w-[46ch]`}>
              Every surface of the AERO GT is shaped to guide the boundary layer cleanly from the
              front splitter to the active rear diffuser. Nothing is decoration. Everything is flow.
            </p>
          </Reveal>
        </div>

        <ol className="lg:col-span-6 border-t border-white/15">
          {PRINCIPLES.map((p, i) => (
            <li key={p.n}>
              <Reveal delay={i * 120} className="grid grid-cols-[3.5rem_1fr] sm:grid-cols-[5rem_1fr] gap-4 py-8 sm:py-10 border-b border-white/15">
                <span className="font-display text-sm tracking-[0.2em] text-[#ff3a4d] pt-1.5">{p.n}</span>
                <div>
                  <h3 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight mb-3">{p.title}</h3>
                  <p className="text-[15px] leading-relaxed text-zinc-400 max-w-[42ch]">{p.text}</p>
                </div>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>

      <Reveal delay={100} className="mt-16 sm:mt-24">
        <dl className="grid sm:grid-cols-3 gap-px rounded-2xl overflow-hidden bg-white/10 border border-white/10 backdrop-blur-md">
          {FACTS.map((f) => (
            <div key={f.label} className="bg-black/45 px-6 sm:px-8 py-7">
              <dt className="text-[11px] uppercase tracking-[0.14em] text-zinc-400 mb-2">{f.label}</dt>
              <dd className="font-display text-xl sm:text-2xl font-semibold">{f.value}</dd>
            </div>
          ))}
        </dl>
      </Reveal>
    </Shell>
  );
}
