import { useEffect, useRef, useState } from 'react';

interface Stat {
  label: string;
  value: number;
  decimals?: number;
  unit: string;
  note: string;
}

const HERO_STATS: Stat[] = [
  { label: '0–60 mph', value: 2.1, decimals: 1, unit: 's', note: 'Dual-motor launch with torque vectoring on every axle.' },
  { label: 'WLTP range', value: 480, unit: 'mi', note: 'Grand-touring distance without compromising output.' },
  { label: 'Peak output', value: 1120, unit: 'hp', note: 'Sustained, repeatable power — lap after lap.' },
];

const DETAILS: Array<{ label: string; value: string }> = [
  { label: 'Drag coefficient', value: '0.19 Cd' },
  { label: '10–80% charge', value: '11 min' },
  { label: 'Peak charge rate', value: '420 kW' },
  { label: 'Architecture', value: '900V' },
];

function useInView<T extends Element>(threshold = 0.25) {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setSeen(true); io.disconnect(); } },
      { threshold },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return [ref, seen] as const;
}

function CountUp({ value, decimals = 0, run }: { value: number; decimals?: number; run: boolean }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (!run) return;
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) { setN(value); return; }
    let raf = 0;
    const start = performance.now(), dur = 1600;
    const step = (t: number) => {
      const p = Math.min((t - start) / dur, 1);
      setN(value * (1 - Math.pow(1 - p, 4))); // easeOutQuart
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [run, value]);
  return <>{n.toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}</>;
}

export function PerformanceSection() {
  const [ref, seen] = useInView<HTMLElement>(0.2);
  const reveal = (i: number) => ({
    style: { transitionDelay: `${i * 120}ms` },
    className: `transition-all duration-[900ms] ease-out ${seen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'}`,
  });

  return (
    <section
      ref={ref}
      aria-labelledby="performance-heading"
      className="relative z-10 w-full text-white overflow-hidden"
    >
      {/* Legibility scrim: lets the fixed animation show through while text stays readable */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-black/55 to-black/55 pointer-events-none" aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent pointer-events-none" aria-hidden="true" />

      <div className="relative max-w-[1440px] mx-auto px-5 sm:px-8 md:px-12 lg:px-16 py-24 sm:py-32 lg:py-40">
        {/* Heading row */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12 items-end mb-16 sm:mb-24">
          <div className="lg:col-span-7">
            <p style={reveal(0).style} className={`font-display text-xs sm:text-sm font-medium tracking-[0.22em] uppercase text-zinc-400 mb-4 flex items-center gap-3 ${reveal(0).className}`}>
              <span className="inline-block w-8 h-px bg-[#e5001c]" aria-hidden="true" />
              Performance
            </p>
            <h2
              id="performance-heading"
              style={reveal(1).style}
              className={`font-display font-semibold uppercase tracking-[-0.025em] leading-[0.96] text-[clamp(2.5rem,7vw,5.5rem)] text-balance ${reveal(1).className}`}
            >
              Engineered<br />for the apex.
            </h2>
          </div>
          <p
            style={reveal(2).style}
            className={`lg:col-span-5 font-sans text-[clamp(1rem,1.5vw,1.1875rem)] leading-[1.6] text-zinc-300/90 max-w-[44ch] ${reveal(2).className}`}
          >
            A 900V solid-state architecture and active underbody aerodynamics deliver
            repeatable track output with silent, composed grand-touring refinement.
          </p>
        </div>

        {/* Headline stats */}
        <dl className="grid md:grid-cols-3 border-t border-white/15">
          {HERO_STATS.map((s, i) => (
            <div
              key={s.label}
              style={reveal(i + 3).style}
              className={`py-10 md:py-14 md:px-8 first:md:pl-0 last:md:pr-0 border-b border-white/15 md:border-b-0 md:border-r last:md:border-r-0 group ${reveal(i + 3).className}`}
            >
              <dt className="font-display text-xs tracking-[0.2em] uppercase text-zinc-400 mb-5">{s.label}</dt>
              <dd>
                <p className="font-display font-semibold tabular-nums tracking-[-0.03em] leading-none text-[clamp(3.5rem,8vw,6.5rem)]">
                  <CountUp value={s.value} decimals={s.decimals} run={seen} />
                  <span className="ml-2 text-[0.3em] font-medium tracking-[0.08em] text-[#ff3a4d] align-baseline">{s.unit}</span>
                </p>
                <p className="mt-5 text-sm sm:text-[15px] leading-relaxed text-zinc-400 max-w-[30ch]">{s.note}</p>
              </dd>
            </div>
          ))}
        </dl>

        {/* Secondary spec strip */}
        <dl
          style={reveal(6).style}
          className={`grid grid-cols-2 lg:grid-cols-4 gap-px rounded-2xl overflow-hidden bg-white/10 border border-white/10 mt-6 backdrop-blur-md ${reveal(6).className}`}
        >
          {DETAILS.map((d) => (
            <div key={d.label} className="bg-black/45 px-5 sm:px-7 py-6 sm:py-8 hover:bg-black/30 transition-colors duration-300">
              <dt className="text-[11px] uppercase tracking-[0.14em] text-zinc-400 mb-2">{d.label}</dt>
              <dd className="font-display text-xl sm:text-2xl font-semibold tabular-nums">{d.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  );
}
