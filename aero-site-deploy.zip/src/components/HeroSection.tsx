import { useEffect, useState } from 'react';
import { Check, Menu, X } from 'lucide-react';
import { AeroLogo } from './AeroLogo';

type NavTopic = 'MODELS' | 'TECH' | 'STORY' | 'CONFIGURATOR';

interface TopicDetail {
  eyebrow: string;
  title: string;
  summary: string;
  specs: Array<{ label: string; value: string }>;
}

const TOPIC_DETAILS: Record<NavTopic, TopicDetail> = {
  MODELS: {
    eyebrow: 'Lineup',
    title: 'AERO GT & GT Performance',
    summary:
      'Dual-motor all-wheel grand touring chassis engineered for sustained high-speed stability and silent cabin composure.',
    specs: [
      { label: '0–60 mph', value: '2.1 s' },
      { label: 'WLTP Range', value: '480 mi' },
      { label: 'Peak Output', value: '1,120 hp' },
    ],
  },
  TECH: {
    eyebrow: 'Architecture',
    title: '900V Solid-State Architecture',
    summary:
      'Active underbody aerodynamics pair with silicon-carbide inverters and structural battery cooling for repeatable track output.',
    specs: [
      { label: 'Drag Coefficient', value: '0.19 Cd' },
      { label: '10–80% Charge', value: '11 min' },
      { label: 'Peak Charge Rate', value: '420 kW' },
    ],
  },
  STORY: {
    eyebrow: 'Philosophy',
    title: 'Sculpted by Airflow',
    summary:
      'Every surface on the AERO GT is shaped to guide boundary-layer flow cleanly from the front splitter to the active rear diffuser.',
    specs: [
      { label: 'Curb Weight', value: '4,180 lb' },
      { label: 'Chassis', value: 'Carbon Monocoque' },
      { label: 'Production', value: 'Limited Series' },
    ],
  },
  CONFIGURATOR: {
    eyebrow: 'Bespoke Trim',
    title: 'Tailor Your Allocation',
    summary:
      'Select from forged aero wheel assemblies, satin obsidian or liquid titanium finishes, and tailored aniline leather interiors.',
    specs: [
      { label: 'Exterior Finishes', value: '6 Studio Coats' },
      { label: 'Wheel Options', value: '21" / 22" Forged' },
      { label: 'First Deliveries', value: 'Q4 2026' },
    ],
  },
};

const NAV_ITEMS: NavTopic[] = ['MODELS', 'TECH', 'STORY', 'CONFIGURATOR'];
const SECTION_ID: Record<NavTopic, string> = { MODELS: 'models', TECH: 'tech', STORY: 'story', CONFIGURATOR: 'configurator' };

export function HeroSection() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeTopic, setActiveTopic] = useState<NavTopic | null>(null);
  const [reserveOpen, setReserveOpen] = useState(false);
  const [selectedEdition, setSelectedEdition] = useState<'AERO GT' | 'AERO GT Track'>('AERO GT');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [formError, setFormError] = useState('');
  const [reservationConfirmed, setReservationConfirmed] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMobileMenuOpen(false);
        setActiveTopic(null);
        setReserveOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const openTopic = (topic: NavTopic) => {
    setMobileMenuOpen(false);
    setReserveOpen(false);
    document.getElementById(SECTION_ID[topic])?.scrollIntoView({ behavior: 'smooth' });
  };

  const openReserve = () => {
    setMobileMenuOpen(false);
    setActiveTopic(null);
    setFormError('');
    setReservationConfirmed(false);
    setReserveOpen(true);
  };

  useEffect(() => {
    const open = () => openReserve();
    window.addEventListener('aero:reserve', open);
    return () => window.removeEventListener('aero:reserve', open);
  }, []);

  const handleReserveSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const trimmedName = fullName.trim();
    const trimmedEmail = email.trim();
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (trimmedName.length < 2) {
      setFormError('Please enter your full name.');
      return;
    }
    if (!emailPattern.test(trimmedEmail)) {
      setFormError('Please enter a valid email address.');
      return;
    }

    setFormError('');
    setReservationConfirmed(true);
  };

  const currentDetail = activeTopic ? TOPIC_DETAILS[activeTopic] : null;

  return (
    <div className="relative min-h-dvh w-full flex flex-col justify-between bg-transparent text-white overflow-x-clip">
      {/* Top Navigation Bar — 3-Zone Contract */}
      <header className={`fixed top-0 inset-x-0 z-30 transition-all duration-300 ${scrolled ? 'bg-black/55 backdrop-blur-md border-b border-white/10' : 'border-b border-transparent'}`}>
        <div className={`w-full max-w-[1440px] mx-auto px-5 sm:px-8 md:px-12 lg:px-16 flex items-center justify-between gap-8 transition-all duration-300 ${scrolled ? 'py-3 sm:py-4' : 'pt-6 sm:pt-8 pb-4'}`}>
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveTopic(null);
            setReserveOpen(false);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="inline-flex items-center text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white rounded-sm whitespace-nowrap shrink-0"
          aria-label="AERO Home"
        >
          <AeroLogo className="h-[15px] sm:h-[17px] md:h-[19px] w-auto" />
        </a>

        {/* Zone 2: Primary Navigation Links */}
        <nav
          aria-label="Primary"
          className="hidden md:flex items-center gap-7 lg:gap-10"
        >
          {NAV_ITEMS.map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => openTopic(item)}
              className="font-display text-xs lg:text-[13px] font-medium tracking-[0.14em] text-zinc-400 hover:text-white transition-colors duration-200 whitespace-nowrap shrink-0 py-2 border-b border-transparent hover:border-white/50 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white cursor-pointer"
            >
              {item}
            </button>
          ))}
        </nav>

        {/* Zone 3: Single Primary Action + Mobile Trigger */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={openReserve}
            className="hidden sm:inline-flex items-center justify-center min-h-[40px] px-6 py-2 rounded-full border border-white/30 bg-white/[0.04] hover:bg-white hover:text-[#090A0C] hover:border-white font-display text-xs font-medium tracking-[0.14em] text-white transition-colors duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white cursor-pointer"
          >
            RESERVE
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="md:hidden inline-flex items-center justify-center min-h-[44px] min-w-[44px] -mr-2 text-zinc-200 hover:text-white transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white rounded-full cursor-pointer"
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileMenuOpen}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        </div>
      </header>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-[#090A0C]/98 backdrop-blur-sm flex flex-col justify-between px-6 py-7">
          <div className="flex items-center justify-between">
            <AeroLogo className="h-[16px] w-auto text-white" />
            <button
              type="button"
              onClick={() => setMobileMenuOpen(false)}
              className="inline-flex items-center justify-center min-h-[44px] min-w-[44px] -mr-2 text-zinc-200 hover:text-white rounded-full focus-visible:outline-2 focus-visible:outline-white cursor-pointer"
              aria-label="Close navigation menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <nav aria-label="Mobile" className="flex flex-col gap-2 my-auto">
            {NAV_ITEMS.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => openTopic(item)}
                className="text-left font-display text-2xl font-medium tracking-[0.08em] text-zinc-200 hover:text-white py-3.5 border-b border-white/10 transition-colors cursor-pointer"
              >
                {item}
              </button>
            ))}
          </nav>

          <button
            type="button"
            onClick={openReserve}
            className="w-full min-h-[48px] rounded-full bg-white text-[#090A0C] font-display text-xs font-semibold tracking-[0.14em] hover:bg-zinc-200 transition-colors cursor-pointer"
          >
            RESERVE NOW
          </button>
        </div>
      )}

      {/* Main Hero Content — Clean Transparent/No-Background Layout */}
      <main
        id="top"
        className="flex-1 w-full max-w-[1440px] mx-auto px-5 sm:px-8 md:px-12 lg:px-16 flex items-center pt-28 pb-12 sm:pt-32 sm:pb-16 md:pt-36 md:pb-20"
      >
        <section
          aria-labelledby="hero-heading"
          className="w-full max-w-2xl flex flex-col items-start"
        >
          {/* Kicker */}
          <p className="font-display text-xs sm:text-sm md:text-[15px] font-medium tracking-[0.22em] text-zinc-400 uppercase mb-3 sm:mb-4">
            AERO GT
          </p>

          {/* Fluid Responsive Display Headline */}
          <h1
            id="hero-heading"
            className="font-display font-semibold uppercase text-white tracking-[-0.025em] leading-[0.96] text-[clamp(2.625rem,11vw,5.5rem)] sm:text-[clamp(3.5rem,8vw,5.5rem)] text-balance mb-5 sm:mb-6"
          >
            <span className="block">BEYOND</span>
            <span className="block">MOTION.</span>
          </h1>

          {/* Subheadline */}
          <p className="font-sans text-[clamp(0.95rem,3.6vw,1.1875rem)] sm:text-[clamp(1.0625rem,1.6vw,1.25rem)] leading-[1.55] text-zinc-300/90 font-normal max-w-[34ch] mb-8 sm:mb-10">
            The ultimate electric grand tourer,{' '}
            <span className="sm:block">built for the next era.</span>
          </p>

          {/* CTA Action Group */}
          <div className="w-full sm:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 sm:gap-4">
            <button
              type="button"
              onClick={openReserve}
              className="inline-flex items-center justify-center min-h-[46px] sm:min-h-[48px] px-7 sm:px-8 py-3 rounded-full bg-white text-[#090A0C] hover:bg-zinc-200 active:scale-[0.99] font-display text-xs sm:text-[13px] font-semibold tracking-[0.1em] uppercase transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white cursor-pointer"
            >
              RESERVE NOW
            </button>

            <button
              type="button"
              onClick={() => openTopic('TECH')}
              className="inline-flex items-center justify-center min-h-[46px] sm:min-h-[48px] px-7 sm:px-8 py-3 rounded-full border border-white/30 bg-transparent text-white hover:border-white/75 hover:bg-white/[0.06] active:scale-[0.99] font-display text-xs sm:text-[13px] font-medium tracking-[0.1em] uppercase transition-all duration-200 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white cursor-pointer"
            >
              DISCOVER THE TECH
            </button>
          </div>
        </section>
      </main>

      {/* Bottom Spacer for Balanced Vertical Framing */}
      <div className="h-6 sm:h-10 shrink-0" aria-hidden="true" />

      {/* Interactive Specification Drawer (Nav Links & Discover The Tech) */}
      {currentDetail && activeTopic && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="topic-modal-title"
          onClick={() => setActiveTopic(null)}
        >
          <div
            className="w-full sm:max-w-lg bg-[#111317] border border-white/15 rounded-t-2xl sm:rounded-2xl p-6 sm:p-8 text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 mb-5">
              <div>
                <p className="font-display text-xs tracking-[0.2em] uppercase text-zinc-400 mb-1.5">
                  {currentDetail.eyebrow}
                </p>
                <h2
                  id="topic-modal-title"
                  className="font-display text-2xl sm:text-[28px] font-semibold tracking-tight text-white"
                >
                  {currentDetail.title}
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setActiveTopic(null)}
                className="inline-flex items-center justify-center min-h-[40px] min-w-[40px] rounded-full border border-white/15 text-zinc-300 hover:text-white hover:border-white/40 transition-colors cursor-pointer"
                aria-label="Close specification panel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm sm:text-[15px] leading-relaxed text-zinc-300 mb-6">
              {currentDetail.summary}
            </p>

            <div className="grid grid-cols-3 gap-4 py-4 border-y border-white/10 mb-6">
              {currentDetail.specs.map((spec) => (
                <div key={spec.label}>
                  <p className="text-[11px] uppercase tracking-[0.12em] text-zinc-400 mb-1">
                    {spec.label}
                  </p>
                  <p className="font-display text-base sm:text-lg font-semibold tabular-nums text-white">
                    {spec.value}
                  </p>
                </div>
              ))}
            </div>

            <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-between gap-3">
              <div className="flex items-center gap-2 overflow-x-auto">
                {NAV_ITEMS.map((item) => (
                  <button
                    key={item}
                    type="button"
                    onClick={() => setActiveTopic(item)}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-display tracking-[0.12em] uppercase transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      activeTopic === item
                        ? 'bg-white text-[#090A0C] font-semibold'
                        : 'text-zinc-400 hover:text-white border border-white/15'
                    }`}
                  >
                    {item}
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={openReserve}
                className="min-h-[42px] px-5 py-2 rounded-full bg-white text-[#090A0C] hover:bg-zinc-200 font-display text-xs font-semibold tracking-[0.1em] uppercase transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                RESERVE NOW
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Reservation Modal */}
      {reserveOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-xs p-0 sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="reserve-modal-title"
          onClick={() => setReserveOpen(false)}
        >
          <div
            className="w-full sm:max-w-md bg-[#111317] border border-white/15 rounded-t-2xl sm:rounded-2xl p-6 sm:p-8 text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-4 mb-5">
              <div>
                <p className="font-display text-xs tracking-[0.2em] uppercase text-zinc-400 mb-1.5">
                  Priority Allocation
                </p>
                <h2
                  id="reserve-modal-title"
                  className="font-display text-2xl font-semibold tracking-tight text-white"
                >
                  Reserve AERO GT
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setReserveOpen(false)}
                className="inline-flex items-center justify-center min-h-[40px] min-w-[40px] rounded-full border border-white/15 text-zinc-300 hover:text-white hover:border-white/40 transition-colors cursor-pointer"
                aria-label="Close reservation dialog"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {reservationConfirmed ? (
              <div className="py-4">
                <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white text-[#090A0C] mb-4">
                  <Check className="w-5 h-5" />
                </div>
                <h3 className="font-display text-xl font-semibold text-white mb-2">
                  Allocation Request Received
                </h3>
                <p className="text-sm text-zinc-300 leading-relaxed mb-6">
                  Thank you, {fullName.trim()}. We have logged your priority interest for the{' '}
                  <span className="text-white font-medium">{selectedEdition}</span> and sent
                  confirmation details to <span className="text-white font-medium">{email.trim()}</span>.
                </p>
                <button
                  type="button"
                  onClick={() => setReserveOpen(false)}
                  className="w-full min-h-[44px] rounded-full bg-white text-[#090A0C] hover:bg-zinc-200 font-display text-xs font-semibold tracking-[0.12em] uppercase transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleReserveSubmit} noValidate className="space-y-4">
                <div>
                  <span className="block text-xs uppercase tracking-[0.14em] text-zinc-400 mb-2">
                    Edition
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {(['AERO GT', 'AERO GT Track'] as const).map((edition) => (
                      <button
                        key={edition}
                        type="button"
                        onClick={() => setSelectedEdition(edition)}
                        className={`min-h-[42px] px-3 py-2 rounded-lg border text-xs font-display font-medium tracking-[0.06em] transition-colors cursor-pointer ${
                          selectedEdition === edition
                            ? 'bg-white text-[#090A0C] border-white font-semibold'
                            : 'bg-transparent text-zinc-300 border-white/15 hover:border-white/40'
                        }`}
                      >
                        {edition}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="reserve-name"
                    className="block text-xs uppercase tracking-[0.14em] text-zinc-400 mb-1.5"
                  >
                    Full Name
                  </label>
                  <input
                    id="reserve-name"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Alex Mercer"
                    className="w-full min-h-[44px] px-3.5 py-2.5 rounded-lg bg-[#090A0C] border border-white/20 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-white transition-colors"
                  />
                </div>

                <div>
                  <label
                    htmlFor="reserve-email"
                    className="block text-xs uppercase tracking-[0.14em] text-zinc-400 mb-1.5"
                  >
                    Email Address
                  </label>
                  <input
                    id="reserve-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alex@example.com"
                    className="w-full min-h-[44px] px-3.5 py-2.5 rounded-lg bg-[#090A0C] border border-white/20 text-sm text-white placeholder:text-zinc-500 focus:outline-none focus:border-white transition-colors"
                  />
                </div>

                {formError && (
                  <p role="alert" className="text-xs text-rose-400">
                    {formError}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full min-h-[46px] mt-2 rounded-full bg-white text-[#090A0C] hover:bg-zinc-200 font-display text-xs font-semibold tracking-[0.12em] uppercase transition-colors cursor-pointer"
                >
                  Confirm Reservation Request
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
