interface AeroLogoProps {
  className?: string;
}

export function AeroLogo({ className = 'h-4 w-auto sm:h-[18px]' }: AeroLogoProps) {
  return (
    <svg
      viewBox="0 0 132 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="AERO"
    >
      {/* Geometric Apex A without crossbar */}
      <path
        d="M2.5 20L13.2 2H15.8L26.5 20H22.3L14.5 6.4L6.7 20H2.5Z"
        fill="currentColor"
      />
      {/* Wide Geometric E */}
      <path
        d="M35 2H57V5.3H38.8V9.4H54.2V12.6H38.8V16.7H57.4V20H35V2Z"
        fill="currentColor"
      />
      {/* Wide Geometric R */}
      <path
        d="M66.5 2H82.6C87.4 2 90.4 4.4 90.4 8.2C90.4 11.4 88.2 13.5 84.5 14.1L91.2 20H85.8L79.8 14.4H70.3V20H66.5V2ZM70.3 5.2V11.3H82.1C84.8 11.3 86.5 10.1 86.5 8.2C86.5 6.3 84.8 5.2 82.1 5.2H70.3Z"
        fill="currentColor"
      />
      {/* Wide Geometric O */}
      <path
        d="M114.5 1.8C124.2 1.8 129.5 5.4 129.5 11C129.5 16.6 124.2 20.2 114.5 20.2C104.8 20.2 99.5 16.6 99.5 11C99.5 5.4 104.8 1.8 114.5 1.8ZM114.5 5.1C107.1 5.1 103.5 7.4 103.5 11C103.5 14.6 107.1 16.9 114.5 16.9C121.9 16.9 125.5 14.6 125.5 11C125.5 7.4 121.9 5.1 114.5 5.1Z"
        fill="currentColor"
      />
    </svg>
  );
}
