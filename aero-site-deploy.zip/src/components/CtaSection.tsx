import { Reveal, Shell, H2, BTN_PRIMARY, openReserve } from './ui';

export function CtaSection() {
  return (
    <Shell labelledBy="cta-heading" scrim="bg-black/45">
      <div className="py-8 sm:py-16 text-center flex flex-col items-center">
        <Reveal><p className="font-display text-xs sm:text-sm tracking-[0.22em] uppercase text-zinc-300 mb-6">First deliveries Q4 2026</p></Reveal>
        <Reveal delay={100}><h2 id="cta-heading" className={`${H2} text-[clamp(2.75rem,9vw,7rem)]`}>Beyond<br />motion.</h2></Reveal>
        <Reveal delay={200}>
          <p className="font-sans text-lg text-zinc-300 mt-8 mb-10 max-w-[40ch] mx-auto">Secure your priority allocation of the AERO GT.</p>
          <button type="button" onClick={openReserve} className={BTN_PRIMARY}>Reserve now</button>
        </Reveal>
      </div>
    </Shell>
  );
}
