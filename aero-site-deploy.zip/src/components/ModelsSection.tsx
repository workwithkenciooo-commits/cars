import { Check } from 'lucide-react';
import { Kicker, Reveal, Shell, H2, LEAD, BTN_PRIMARY, BTN_GHOST, openReserve } from './ui';

const MODELS = [
  {
    name: 'AERO GT',
    tag: 'Grand touring',
    blurb: 'The reference edition: silent, composed and devastatingly quick over any distance.',
    stats: [['0–60 mph', '2.1 s'], ['Range', '480 mi'], ['Output', '1,120 hp']],
    features: ['Dual-motor all-wheel drive', 'Adaptive air suspension', 'Aniline leather interior', '21" forged wheels'],
    featured: false,
  },
  {
    name: 'AERO GT Track',
    tag: 'Circuit focused',
    blurb: 'Sharper calibration and more downforce for drivers who measure life in lap times.',
    stats: [['0–60 mph', '2.1 s'], ['Peak charge', '420 kW'], ['Output', '1,120 hp']],
    features: ['Track-tuned chassis calibration', 'Increased downforce package', 'Carbon-ceramic brakes', '22" forged wheels'],
    featured: true,
  },
];

export function ModelsSection() {
  return (
    <Shell id="models" labelledBy="models-heading" scrim="bg-black/60">
      <div className="max-w-2xl mb-16 sm:mb-20">
        <Reveal><Kicker>Lineup</Kicker></Reveal>
        <Reveal delay={100}><h2 id="models-heading" className={H2}>Choose<br />your edition.</h2></Reveal>
        <Reveal delay={200}><p className={`${LEAD} mt-8 max-w-[46ch]`}>Two expressions of the same dual-motor grand-touring chassis.</p></Reveal>
      </div>

      <div className="grid md:grid-cols-2 gap-4 lg:gap-6">
        {MODELS.map((m, i) => (
          <Reveal key={m.name} delay={i * 150}>
            <article className={`h-full flex flex-col rounded-3xl border backdrop-blur-md p-7 sm:p-10 ${m.featured ? 'border-white/30 bg-white/[0.06]' : 'border-white/10 bg-black/40'}`}>
              <div className="flex items-center justify-between gap-4 mb-8">
                <p className="font-display text-xs tracking-[0.2em] uppercase text-zinc-400">{m.tag}</p>
                {m.featured && <span className="font-display text-[11px] tracking-[0.14em] uppercase px-3 py-1 rounded-full bg-[#e5001c] text-white">Track</span>}
              </div>
              <h3 className="font-display text-4xl sm:text-5xl font-semibold tracking-tight mb-4">{m.name}</h3>
              <p className="text-[15px] leading-relaxed text-zinc-300 max-w-[40ch] mb-8">{m.blurb}</p>

              <dl className="grid grid-cols-3 gap-4 py-6 border-y border-white/10 mb-8">
                {m.stats.map(([l, v]) => (
                  <div key={l}>
                    <dt className="text-[11px] uppercase tracking-[0.12em] text-zinc-400 mb-1">{l}</dt>
                    <dd className="font-display text-lg sm:text-xl font-semibold tabular-nums">{v}</dd>
                  </div>
                ))}
              </dl>

              <ul className="space-y-3 mb-10">
                {m.features.map((f) => (
                  <li key={f} className="flex items-start gap-3 text-sm text-zinc-300">
                    <Check className="w-4 h-4 mt-0.5 shrink-0 text-[#ff3a4d]" aria-hidden="true" /> {f}
                  </li>
                ))}
              </ul>

              <button type="button" onClick={openReserve} className={`mt-auto w-full sm:w-auto self-start ${m.featured ? BTN_PRIMARY : BTN_GHOST}`}>
                Reserve {m.name}
              </button>
            </article>
          </Reveal>
        ))}
      </div>
    </Shell>
  );
}
