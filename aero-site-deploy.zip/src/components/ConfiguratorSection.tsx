import { useState } from 'react';
import { Kicker, Reveal, Shell, H2, LEAD, BTN_PRIMARY, openReserve } from './ui';

const FINISHES = [
  { name: 'Signal Red', color: '#c40018' },
  { name: 'Satin Obsidian', color: '#15161a' },
  { name: 'Liquid Titanium', color: '#8a8f98' },
  { name: 'Arctic White', color: '#ececec' },
  { name: 'Deep Cobalt', color: '#14338f' },
  { name: 'Forest Green', color: '#12452d' },
];
const WHEELS = ['21" Forged', '22" Forged'];
const INTERIORS = [
  { name: 'Obsidian', color: '#1b1b1d' },
  { name: 'Bone', color: '#cfc6b6' },
  { name: 'Oxblood', color: '#5a0f1a' },
];

function Swatch({ color, label, active, onClick }: { color: string; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      aria-pressed={active}
      title={label}
      className={`w-11 h-11 rounded-full border-2 transition-all duration-200 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${active ? 'border-white scale-110' : 'border-white/20 hover:border-white/60'}`}
      style={{ background: color }}
    />
  );
}

export function ConfiguratorSection() {
  const [finish, setFinish] = useState(FINISHES[0]);
  const [wheel, setWheel] = useState(WHEELS[0]);
  const [interior, setInterior] = useState(INTERIORS[0]);

  return (
    <Shell id="configurator" labelledBy="config-heading">
      <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        <div className="lg:col-span-6">
          <Reveal><Kicker>Bespoke trim</Kicker></Reveal>
          <Reveal delay={100}><h2 id="config-heading" className={H2}>Tailor your<br />allocation.</h2></Reveal>
          <Reveal delay={200}><p className={`${LEAD} mt-8 mb-12 max-w-[46ch]`}>Six studio coats, forged aero wheel assemblies and tailored aniline leather. First deliveries Q4 2026.</p></Reveal>

          <Reveal delay={250} className="space-y-9">
            <fieldset>
              <legend className="text-xs uppercase tracking-[0.14em] text-zinc-400 mb-4">Exterior — <span className="text-white">{finish.name}</span></legend>
              <div className="flex flex-wrap gap-3">
                {FINISHES.map((f) => <Swatch key={f.name} color={f.color} label={f.name} active={f.name === finish.name} onClick={() => setFinish(f)} />)}
              </div>
            </fieldset>

            <fieldset>
              <legend className="text-xs uppercase tracking-[0.14em] text-zinc-400 mb-4">Wheels</legend>
              <div className="inline-flex p-1 rounded-full border border-white/15 bg-black/30">
                {WHEELS.map((w) => (
                  <button key={w} type="button" aria-pressed={w === wheel} onClick={() => setWheel(w)}
                    className={`px-5 min-h-[40px] rounded-full font-display text-xs tracking-[0.08em] transition-colors cursor-pointer ${w === wheel ? 'bg-white text-[#090A0C] font-semibold' : 'text-zinc-300 hover:text-white'}`}>
                    {w}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend className="text-xs uppercase tracking-[0.14em] text-zinc-400 mb-4">Interior — <span className="text-white">{interior.name}</span></legend>
              <div className="flex gap-3">
                {INTERIORS.map((n) => <Swatch key={n.name} color={n.color} label={n.name} active={n.name === interior.name} onClick={() => setInterior(n)} />)}
              </div>
            </fieldset>
          </Reveal>
        </div>

        {/* Live build summary */}
        <Reveal delay={200} className="lg:col-span-6">
          <div className="rounded-3xl border border-white/10 bg-black/40 backdrop-blur-md p-7 sm:p-10">
            <div className="relative aspect-[16/10] rounded-2xl overflow-hidden border border-white/10 mb-8" aria-hidden="true">
              <div className="absolute inset-0 transition-colors duration-500" style={{ background: `radial-gradient(120% 90% at 30% 20%, ${finish.color}, #050506 75%)` }} />
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/10 to-transparent" />
              <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between">
                <span className="font-display text-xs tracking-[0.2em] uppercase text-white/80">{finish.name}</span>
                <span className="w-9 h-9 rounded-full border border-white/40 transition-colors duration-500" style={{ background: interior.color }} />
              </div>
            </div>
            <p className="font-display text-xs tracking-[0.2em] uppercase text-zinc-400 mb-2">Your AERO GT</p>
            <dl className="divide-y divide-white/10 border-y border-white/10 mb-8">
              {[['Exterior', finish.name], ['Wheels', wheel], ['Interior', interior.name]].map(([l, v]) => (
                <div key={l} className="flex justify-between py-4 text-sm">
                  <dt className="text-zinc-400">{l}</dt><dd className="font-display font-medium">{v}</dd>
                </div>
              ))}
            </dl>
            <button type="button" onClick={openReserve} className={`${BTN_PRIMARY} w-full`}>Reserve this build</button>
          </div>
        </Reveal>
      </div>
    </Shell>
  );
}
