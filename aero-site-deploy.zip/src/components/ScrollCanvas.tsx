import { useEffect, useRef } from 'react';

const FRAME_COUNT = 209;
const EASE = 0.085; // lower = smoother / longer glide
const framePath = (i: number) => `${import.meta.env.BASE_URL}frames/${String(i + 1).padStart(3, '0')}.webp`;

/** Fixed full-bleed canvas that plays image frames across the scroll progress of the whole page. */
export function ScrollCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    const frames: (HTMLImageElement | undefined)[] = new Array(FRAME_COUNT);
    let w = 0, h = 0, target = 0, current = 0, last = performance.now(), dirty = true, raf = 0, dead = false;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.width = Math.round(innerWidth * dpr);
      h = canvas.height = Math.round(innerHeight * dpr);
      dirty = true;
    };
    const readScroll = () => {
      const max = document.documentElement.scrollHeight - innerHeight;
      const p = max > 0 ? Math.min(Math.max(scrollY / max, 0), 1) : 0;
      target = p * (FRAME_COUNT - 1);
    };
    const pick = (i: number) => {
      for (let d = 0; d < FRAME_COUNT; d++) {
        if (frames[i - d]) return frames[i - d];
        if (frames[i + d]) return frames[i + d];
      }
    };
    const draw = (img: HTMLImageElement | undefined, alpha: number) => {
      if (!img) return;
      const s = Math.max(w / img.width, h / img.height);
      const dw = img.width * s, dh = img.height * s;
      ctx.globalAlpha = alpha;
      ctx.drawImage(img, (w - dw) / 2, (h - dh) / 2, dw, dh);
    };
    const render = () => {
      const i = Math.floor(current), f = current - i;
      const a = pick(i), b = pick(Math.min(i + 1, FRAME_COUNT - 1));
      draw(a, 1);
      if (f > 0.001 && b !== a) draw(b, f);
      ctx.globalAlpha = 1;
    };
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 16.667, 3);
      last = now;
      const k = 1 - Math.pow(1 - EASE, dt);
      const diff = target - current;
      if (Math.abs(diff) > 0.0005) { current += diff * k; dirty = true; }
      else if (current !== target) { current = target; dirty = true; }
      if (dirty) { render(); dirty = false; }
      raf = requestAnimationFrame(tick);
    };
    const load = (i: number) =>
      new Promise<void>((res) => {
        const img = new Image();
        img.decoding = 'async';
        img.onload = () => { frames[i] = img; dirty = true; res(); };
        img.onerror = () => res();
        img.src = framePath(i);
      });
    const preload = async () => {
      await load(0);
      let n = 1;
      const worker = async () => { while (!dead && n < FRAME_COUNT) await load(n++); };
      await Promise.all(Array.from({ length: 6 }, worker));
    };
    const onResize = () => { resize(); readScroll(); };

    resize(); readScroll(); current = target;
    addEventListener('resize', onResize);
    addEventListener('scroll', readScroll, { passive: true });
    preload();
    raf = requestAnimationFrame(tick);
    return () => {
      dead = true;
      cancelAnimationFrame(raf);
      removeEventListener('resize', onResize);
      removeEventListener('scroll', readScroll);
    };
  }, []);

  return <canvas ref={canvasRef} className="fixed inset-0 z-0 w-full h-full block" aria-hidden="true" />;
}
